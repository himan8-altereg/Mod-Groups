using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// Adds group controls above the vanilla mod list. The original RimWorld
    /// page remains responsible for drawing and operating its complete UI.
    /// NOTE: if this fails to patch after a RimWorld update, open Page_ModsConfig
    /// in a decompiler (dnSpy/ILSpy) and confirm the method name/signature/param
    /// name below still matches — Ludeon occasionally renames internals between
    /// versions (confirmed: in 1.6.4871 the parameter is "rect", not "inRect").
    /// </summary>
    [HarmonyPatch(typeof(Page_ModsConfig), "DoWindowContents")]
    public static class Patch_PageModsConfig_DoWindowContents
    {
        private static bool groupedListsEnabled = true;
        // "__0" binds to the original method's first parameter *by position*,
        // not by name. This is what broke last time (Ludeon renamed the param
        // from "inRect" to "rect" between builds) - positional binding survives
        // that kind of rename. It will still break if RimWorld changes the
        // parameter's type or the method's parameter count/order entirely.
        public static bool Prefix(ref Rect __0)
        {
            float buttonWidth = 150f;
            float buttonHeight = 32f;
            float raiseAboveFrame = 10f; // pokes a bit above the window's content edge
            Rect toggleRect = new Rect(__0.xMax - buttonWidth * 2f - 6f, __0.yMin - raiseAboveFrame, buttonWidth, buttonHeight);
            Rect manageRect = new Rect(__0.xMax - buttonWidth, __0.yMin - raiseAboveFrame, buttonWidth, buttonHeight);

            if (Widgets.ButtonText(toggleRect, groupedListsEnabled ? "MG_GroupsOn".Translate() : "MG_GroupsOff".Translate()))
            {
                groupedListsEnabled = !groupedListsEnabled;
            }
            if (Widgets.ButtonText(manageRect, "MG_ManageGroups".Translate()))
            {
                Find.WindowStack.Add(new Dialog_ModGroups());
            }

            // Reserve the strip so vanilla content remains unobstructed.
            __0.yMin += buttonHeight + 6f - raiseAboveFrame;
            return true;
        }

        public static bool GroupedListsEnabled => groupedListsEnabled;

        public static ModGroup FindGroup(string packageId)
        {
            var settings = ModGroupsMod.Settings;
            return settings?.groups?.FirstOrDefault(g => g.packageIds != null && g.packageIds.Contains(packageId));
        }
    }

    /// <summary>Draws expandable group headers inside RimWorld's native mod columns.</summary>
    [HarmonyPatch(typeof(Page_ModsConfig), "DoModList")]
    public static class Patch_PageModsConfig_DoModList
    {
        private sealed class GroupModsEntry
        {
            public ModGroup Group;
            public List<ModMetaData> Mods;
        }

        private static readonly System.Reflection.MethodInfo DrawVanillaRow = AccessTools.Method(typeof(Page_ModsConfig), "DoModRow");
        private static readonly System.Reflection.FieldInfo ModRowHeight = AccessTools.Field(typeof(Page_ModsConfig), "ModRowHeight");
        private static readonly System.Reflection.FieldInfo MetaRowHeight = AccessTools.Field(typeof(Page_ModsConfig), "MetaRowHeight");
        private static readonly System.Reflection.FieldInfo InactiveGroupId = AccessTools.Field(typeof(Page_ModsConfig), "inactiveGroupId");
        private static readonly Dictionary<int, bool> ungroupedCollapsedByList = new Dictionary<int, bool>();
        private static bool sharedGroupsCollapsedActive;
        private static bool sharedGroupsCollapsedInactive;
        private static ModGroup pendingDragGroup;
        private static ModGroup activeDragGroup;
        private static string pendingDragPackageId;
        private static string draggedPackageId;
        private static string dragTargetPackageId;
        private static Vector2 dragStartPosition;
        private static int dragControlId;
        private static bool pendingDragInactive;
        private static bool activeDragInactive;
        private static bool dropAfterTarget;
        private static ModGroup pendingHeaderDragGroup;
        private static ModGroup activeHeaderDragGroup;
        private static ModGroup headerDragTarget;
        private static Vector2 headerDragStartPosition;
        private static int headerDragControlId;
        private static bool pendingHeaderDragInactive;
        private static bool activeHeaderDragInactive;
        private static bool dropAfterHeaderTarget;

        public static bool Prefix(Page_ModsConfig __instance, Rect __0, List<ModMetaData> __1, ref Vector2 __2, ref int __3)
        {
            if (!Patch_PageModsConfig_DoWindowContents.GroupedListsEnabled)
                return true;

            float rowHeight = ModRowHeight == null ? 28f : (float)ModRowHeight.GetValue(null);
            float headerHeight = MetaRowHeight == null ? rowHeight : (float)MetaRowHeight.GetValue(null);
            var source = __1 ?? new List<ModMetaData>();
            // RimWorld's list identifier is not stable across all 1.6 builds.
            // The list itself is the reliable signal: enabled/disabled columns
            // contain mods with the corresponding Active state.
            bool inactive = source.Count > 0
                ? source.All(mod => !mod.Active)
                : InactiveGroupId != null && __3 == (int)InactiveGroupId.GetValue(__instance);
            UpdateDragStart(inactive);
            UpdateHeaderDragStart(inactive);
            var settings = ModGroupsMod.Settings;
            if (activeHeaderDragGroup != null && activeHeaderDragInactive == inactive
                && (Event.current.type == EventType.MouseMove || Event.current.type == EventType.MouseDrag
                    || Event.current.type == EventType.MouseUp))
                headerDragTarget = null;
            var membershipsByPackageId = settings.groups
                .SelectMany(group => (group.packageIds ?? new List<string>()).Select(packageId => new { packageId, group }))
                .GroupBy(item => item.packageId)
                .ToDictionary(items => items.Key, items => items.Select(item => item.group).ToList());
            var sharedEntries = !inactive
                ? settings.groups
                    .Select(group => new GroupModsEntry
                    {
                        Group = group,
                        Mods = source.Where(mod => membershipsByPackageId.TryGetValue(mod.PackageId, out var memberships)
                            && memberships.Count > 1 && memberships.Contains(group))
                            .OrderBy(mod => group.packageIds.IndexOf(mod.PackageId)).ToList()
                    })
                    .Where(entry => entry.Mods.Count > 0)
                    .ToList()
                : new List<GroupModsEntry>();
            var sharedPackageIds = new HashSet<string>(sharedEntries.SelectMany(entry => entry.Mods).Select(mod => mod.PackageId));
            var visibleGroups = settings.groups
                .Select(group => new GroupModsEntry
                {
                    Group = group,
                    // In the enabled column shared mods live in the special
                    // shared section. In the disabled column, keep the full
                    // membership in every group so small groups are not
                    // swallowed by whichever group happens to come first.
                    Mods = source.Where(mod => group.packageIds != null
                        && group.packageIds.Contains(mod.PackageId)
                        && (inactive || !sharedPackageIds.Contains(mod.PackageId)))
                        .OrderBy(mod => group.packageIds.IndexOf(mod.PackageId)).ToList()
                })
                .Where(entry => entry.Mods.Count > 0)
                .ToList();
            var groupedIds = new HashSet<string>(visibleGroups.SelectMany(x => x.Mods).Select(m => m.PackageId));
            groupedIds.UnionWith(sharedPackageIds);
            var ungrouped = source.Where(m => !groupedIds.Contains(m.PackageId)).ToList();
            float contentHeight = headerHeight + ungrouped.Count * rowHeight;
            foreach (var entry in visibleGroups)
                contentHeight += headerHeight + (IsCollapsed(entry.Group, inactive) ? 0f : entry.Mods.Count * rowHeight);
            if (sharedEntries.Count > 0)
            {
                contentHeight += headerHeight;
                if (!AreSharedGroupsCollapsed(inactive))
                {
                    foreach (var entry in sharedEntries)
                        contentHeight += headerHeight + (IsSharedGroupCollapsed(entry.Group, inactive) ? 0f : entry.Mods.Count * rowHeight);
                }
            }

            Rect viewRect = new Rect(0f, 0f, __0.width - 16f, contentHeight + 8f);
            Widgets.BeginScrollView(__0, ref __2, viewRect);
            float y = 0f;

            if (sharedEntries.Count > 0)
            {
                y = DrawSharedGroupsHeader(viewRect.width, y, headerHeight, sharedPackageIds.Count, inactive);
                if (!AreSharedGroupsCollapsed(inactive))
                {
                    foreach (var entry in sharedEntries)
                    {
                        y = DrawGroupHeader(viewRect.width, y, headerHeight, entry.Group, entry.Mods, inactive, true);
                        if (!IsSharedGroupCollapsed(entry.Group, inactive))
                            DrawRows(__instance, viewRect.width, ref y, rowHeight, entry.Mods, source, entry.Group, inactive);
                    }
                }
            }

            foreach (var entry in visibleGroups)
            {
                y = DrawGroupHeader(viewRect.width, y, headerHeight, entry.Group, entry.Mods, inactive, false);
                if (!IsCollapsed(entry.Group, inactive))
                    DrawRows(__instance, viewRect.width, ref y, rowHeight, entry.Mods, source, entry.Group, inactive);
            }

            bool ungroupedCollapsed = ungroupedCollapsedByList.ContainsKey(__3) && ungroupedCollapsedByList[__3];
            y = DrawUngroupedHeader(viewRect.width, y, headerHeight, ungrouped.Count, ungroupedCollapsed, __3);
            if (!ungroupedCollapsed)
                DrawRows(__instance, viewRect.width, ref y, rowHeight, ungrouped, source, null, inactive);

            FinishHeaderDragEvents(inactive, settings);
            Widgets.EndScrollView();
            FinishDragEvents(inactive, settings);
            DrawDragPreview(__0, inactive);
            return false;
        }

        private static bool IsCollapsed(ModGroup group, bool inactive)
        {
            return inactive ? group.collapsedInactive : group.collapsedActive;
        }

        private static bool IsSharedGroupCollapsed(ModGroup group, bool inactive)
        {
            return inactive ? group.collapsedSharedInactive : group.collapsedSharedActive;
        }

        private static bool AreSharedGroupsCollapsed(bool inactive)
        {
            return inactive ? sharedGroupsCollapsedInactive : sharedGroupsCollapsedActive;
        }

        private static float DrawGroupHeader(float width, float y, float height, ModGroup group, List<ModMetaData> mods, bool inactive, bool shared)
        {
            Rect rect = new Rect(0f, y, width, height);
            Widgets.DrawBoxSolid(rect, Dialog_ModGroups.GroupColor(group));
            Rect dragRect = new Rect(50f, y, width - 52f, height);
            Rect nameRect = new Rect(52f, y, width - 54f, height);
            HandleGroupHeaderDrag(dragRect, group, inactive, ModGroupsMod.Settings);
            if (activeHeaderDragGroup == group && activeHeaderDragInactive == inactive)
                Widgets.DrawBoxSolid(rect, new Color(0.28f, 0.62f, 0.92f, 0.25f));
            bool collapsed = shared ? IsSharedGroupCollapsed(group, inactive) : IsCollapsed(group, inactive);
            if (Widgets.ButtonText(new Rect(2f, y + 1f, 22f, height - 2f), collapsed ? "+" : "-"))
            {
                if (shared && inactive) group.collapsedSharedInactive = !collapsed;
                else if (shared) group.collapsedSharedActive = !collapsed;
                else if (inactive) group.collapsedInactive = !collapsed;
                else group.collapsedActive = !collapsed;
                ModGroupsMod.Settings.Save();
            }
            bool allActive = mods.Count > 0 && mods.All(m => m.Active);
            bool newState = allActive;
            Widgets.Checkbox(new Vector2(28f, y + (height - 18f) / 2f), ref newState);
            if (newState != allActive)
            {
                foreach (var mod in mods) mod.Active = newState;
                ModsConfig.Save();
            }
            string headerKey = inactive ? "MG_GroupHeaderInactive" : "MG_GroupHeaderActive";
            Widgets.Label(nameRect, headerKey.Translate(group.name, mods.Count));
            if (activeHeaderDragGroup != null && headerDragTarget == group && activeHeaderDragInactive == inactive)
            {
                float markerY = dropAfterHeaderTarget ? rect.yMax - 3f : rect.y;
                Widgets.DrawBoxSolid(new Rect(rect.x, markerY, rect.width, 3f), new Color(0.28f, 0.76f, 1f, 1f));
            }
            return y + height;
        }

        private static void UpdateHeaderDragStart(bool inactive)
        {
            if (pendingHeaderDragGroup == null || pendingHeaderDragInactive != inactive || Event.current.type != EventType.MouseDrag)
                return;
            Vector2 delta = Event.current.mousePosition - headerDragStartPosition;
            if (delta.sqrMagnitude < 25f)
                return;
            activeHeaderDragGroup = pendingHeaderDragGroup;
            headerDragTarget = activeHeaderDragGroup;
            activeHeaderDragInactive = pendingHeaderDragInactive;
            pendingHeaderDragGroup = null;
            GUIUtility.hotControl = headerDragControlId;
        }

        private static void HandleGroupHeaderDrag(Rect nameRect, ModGroup group, bool inactive, ModGroupsSettings settings)
        {
            Event current = Event.current;
            int controlId = GUIUtility.GetControlID(FocusType.Passive);
            if (settings.clickToDragGroups && current.type == EventType.MouseDown && current.button == 0
                && nameRect.Contains(current.mousePosition))
            {
                if (activeHeaderDragGroup == null)
                {
                    activeHeaderDragGroup = group;
                    activeHeaderDragInactive = inactive;
                    headerDragTarget = null;
                    headerDragControlId = controlId;
                }
                else if (activeHeaderDragInactive == inactive)
                {
                    if (TryGetGroupDropSide(nameRect, current.mousePosition, out bool after))
                    {
                        headerDragTarget = group;
                        dropAfterHeaderTarget = after;
                        ReorderGroup(settings, activeHeaderDragGroup, headerDragTarget, dropAfterHeaderTarget);
                        ClearHeaderDrag();
                    }
                    else
                    {
                        current.Use();
                        return;
                    }
                }
                current.Use();
                return;
            }
            if (settings.clickToDragGroups && activeHeaderDragGroup != null && activeHeaderDragInactive == inactive
                && (current.type == EventType.MouseMove || current.type == EventType.Repaint)
                && TryGetGroupDropSide(nameRect, current.mousePosition, out bool clickDropAfter))
            {
                headerDragTarget = group;
                dropAfterHeaderTarget = clickDropAfter;
            }
            if (settings.clickToDragGroups)
                return;
            if (current.type == EventType.MouseDown && current.button == 0 && nameRect.Contains(current.mousePosition)
                && pendingHeaderDragGroup == null && activeHeaderDragGroup == null)
            {
                pendingHeaderDragGroup = group;
                pendingHeaderDragInactive = inactive;
                headerDragStartPosition = current.mousePosition;
                headerDragControlId = controlId;
                return;
            }
            // While dragging, update the insertion target on every group
            // header in this column, not only on the source header.
            if (activeHeaderDragGroup == null || activeHeaderDragInactive != inactive)
                return;
            if ((current.type == EventType.MouseDrag || current.type == EventType.Repaint || current.type == EventType.MouseUp)
                && TryGetGroupDropSide(nameRect, current.mousePosition, out bool dropAfter))
            {
                headerDragTarget = group;
                dropAfterHeaderTarget = dropAfter;
            }
        }

        private static bool TryGetGroupDropSide(Rect headerRect, Vector2 mousePosition, out bool after)
        {
            const float edgeHeight = 5f;
            after = false;
            if (!headerRect.Contains(mousePosition)) return false;
            if (mousePosition.y <= headerRect.yMin + edgeHeight) return true;
            if (mousePosition.y >= headerRect.yMax - edgeHeight)
            {
                after = true;
                return true;
            }
            return false;
        }

        private static void FinishHeaderDragEvents(bool inactive, ModGroupsSettings settings)
        {
            if (settings.clickToDragGroups && activeHeaderDragGroup != null
                && Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                ClearHeaderDrag();
                Event.current.Use();
                return;
            }

            if (pendingHeaderDragGroup != null && pendingHeaderDragInactive == inactive && Event.current.type == EventType.MouseUp)
                pendingHeaderDragGroup = null;

            // In click mode, release after picking up must keep the group
            // attached to the cursor until the second click places it.
            if (settings.clickToDragGroups)
                return;

            if (activeHeaderDragGroup == null || activeHeaderDragInactive != inactive)
                return;
            if (Event.current.type == EventType.MouseDrag)
            {
                Event.current.Use();
                return;
            }
            if (Event.current.type != EventType.MouseUp)
                return;

            ReorderGroup(settings, activeHeaderDragGroup, headerDragTarget, dropAfterHeaderTarget);
            ClearHeaderDrag();
            Event.current.Use();
        }

        private static void ReorderGroup(ModGroupsSettings settings, ModGroup moving, ModGroup target, bool after)
        {
            int sourceIndex = settings.groups.IndexOf(moving);
            int targetIndex = settings.groups.IndexOf(target);
            if (sourceIndex < 0 || targetIndex < 0) return;
            settings.groups.RemoveAt(sourceIndex);
            if (sourceIndex < targetIndex) targetIndex--;
            int insertIndex = targetIndex + (after ? 1 : 0);
            settings.groups.Insert(Math.Max(0, Math.Min(insertIndex, settings.groups.Count)), moving);
            settings.Save();
        }

        private static void ClearHeaderDrag()
        {
            activeHeaderDragGroup = null;
            headerDragTarget = null;
            pendingHeaderDragGroup = null;
            if (GUIUtility.hotControl == headerDragControlId)
                GUIUtility.hotControl = 0;
        }

        private static float DrawSharedGroupsHeader(float width, float y, float height, int count, bool inactive)
        {
            Rect rect = new Rect(0f, y, width, height);
            Widgets.DrawBoxSolid(rect, new Color(0.27f, 0.20f, 0.37f, 0.78f));
            bool collapsed = AreSharedGroupsCollapsed(inactive);
            if (Widgets.ButtonText(new Rect(2f, y + 1f, 22f, height - 2f), collapsed ? "+" : "-"))
            {
                if (inactive) sharedGroupsCollapsedInactive = !collapsed;
                else sharedGroupsCollapsedActive = !collapsed;
            }
            Widgets.Label(new Rect(30f, y, width - 32f, height), "MG_SharedGroupsHeader".Translate(count));
            return y + height;
        }

        private static float DrawUngroupedHeader(float width, float y, float height, int count, bool collapsed, int listId)
        {
            Rect rect = new Rect(0f, y, width, height);
            Widgets.DrawBoxSolid(rect, new Color(0.15f, 0.15f, 0.15f, 0.65f));
            if (Widgets.ButtonText(new Rect(2f, y + 1f, 22f, height - 2f), collapsed ? "+" : "-"))
                ungroupedCollapsedByList[listId] = !collapsed;
            Widgets.Label(new Rect(30f, y, width - 32f, height), "MG_UngroupedCount".Translate(count));
            return y + height;
        }

        private static void DrawRows(Page_ModsConfig page, float width, ref float y, float rowHeight, List<ModMetaData> mods, List<ModMetaData> fullList, ModGroup group, bool inactive)
        {
            foreach (var mod in mods)
            {
                int index = fullList.IndexOf(mod);
                Rect rowRect = new Rect(0f, y, width, rowHeight);
                if (activeHeaderDragGroup == null)
                    HandleGroupRowDrag(rowRect, mod, group, inactive);
                EventType eventType = Event.current.type;
                bool suppressVanillaDragInput = eventType != EventType.Repaint
                    && eventType != EventType.Layout
                    && (activeHeaderDragGroup != null
                        || (draggedPackageId != null && activeDragInactive == inactive));
                if (!suppressVanillaDragInput)
                    DrawVanillaRow.Invoke(page, new object[] { rowRect, mod, fullList, index, false });

                if (eventType == EventType.Repaint && activeHeaderDragGroup == null && draggedPackageId != null && activeDragInactive == inactive)
                {
                    if (group == activeDragGroup && mod.PackageId == draggedPackageId)
                        Widgets.DrawBoxSolid(rowRect, new Color(0.24f, 0.58f, 0.92f, 0.30f));
                    if (group == activeDragGroup && mod.PackageId == dragTargetPackageId)
                    {
                        float markerY = dropAfterTarget ? rowRect.yMax - 2f : rowRect.y;
                        Widgets.DrawBoxSolid(new Rect(rowRect.x, markerY, rowRect.width, 3f), new Color(0.28f, 0.76f, 1f, 1f));
                    }
                }
                y += rowHeight;
            }
        }

        private static void UpdateDragStart(bool inactive)
        {
            if (pendingDragPackageId == null || pendingDragInactive != inactive || Event.current.type != EventType.MouseDrag)
                return;

            Vector2 delta = Event.current.mousePosition - dragStartPosition;
            if (delta.sqrMagnitude < 25f)
                return;

            draggedPackageId = pendingDragPackageId;
            dragTargetPackageId = draggedPackageId;
            activeDragGroup = pendingDragGroup;
            activeDragInactive = pendingDragInactive;
            pendingDragPackageId = null;
            pendingDragGroup = null;
            GUIUtility.hotControl = dragControlId;
        }

        private static void HandleGroupRowDrag(Rect rowRect, ModMetaData mod, ModGroup group, bool inactive)
        {
            if (group == null)
                return;

            Event current = Event.current;
            int controlId = GUIUtility.GetControlID(FocusType.Passive);
            if (current.type == EventType.MouseDown && current.button == 0 && rowRect.Contains(current.mousePosition)
                && draggedPackageId == null && pendingDragPackageId == null)
            {
                pendingDragPackageId = mod.PackageId;
                pendingDragGroup = group;
                pendingDragInactive = inactive;
                dragStartPosition = current.mousePosition;
                dragControlId = controlId;
                return;
            }

            if (draggedPackageId == null || activeDragGroup != group || activeDragInactive != inactive)
                return;

            if ((current.type == EventType.MouseDrag || current.type == EventType.Repaint || current.type == EventType.MouseUp)
                && rowRect.Contains(current.mousePosition))
            {
                dragTargetPackageId = mod.PackageId;
                dropAfterTarget = current.mousePosition.y >= rowRect.center.y;
            }
        }

        private static void FinishDragEvents(bool inactive, ModGroupsSettings settings)
        {
            if (pendingDragPackageId != null && pendingDragInactive == inactive && Event.current.type == EventType.MouseUp)
            {
                pendingDragPackageId = null;
                pendingDragGroup = null;
            }

            if (draggedPackageId == null || activeDragInactive != inactive)
                return;

            if (Event.current.type == EventType.MouseUp)
            {
                int sourceIndex = activeDragGroup.packageIds.IndexOf(draggedPackageId);
                int targetIndex = activeDragGroup.packageIds.IndexOf(dragTargetPackageId);
                if (sourceIndex >= 0 && targetIndex >= 0 && sourceIndex != targetIndex)
                {
                    string packageId = activeDragGroup.packageIds[sourceIndex];
                    activeDragGroup.packageIds.RemoveAt(sourceIndex);
                    if (sourceIndex < targetIndex)
                        targetIndex--;
                    int insertIndex = targetIndex + (dropAfterTarget ? 1 : 0);
                    activeDragGroup.packageIds.Insert(Math.Max(0, Math.Min(insertIndex, activeDragGroup.packageIds.Count)), packageId);
                    settings.Save();
                }
                ClearActiveDrag();
                Event.current.Use();
            }
            else if (Event.current.type == EventType.MouseDrag)
            {
                Event.current.Use();
            }
        }

        private static void DrawDragPreview(Rect listRect, bool inactive)
        {
            bool draggingMod = draggedPackageId != null && activeDragInactive == inactive;
            bool draggingGroup = activeHeaderDragGroup != null && activeHeaderDragInactive == inactive;
            if ((!draggingMod && !draggingGroup) || Event.current.type != EventType.Repaint)
                return;

            string label = draggingGroup
                ? activeHeaderDragGroup.name
                : ModLister.GetModWithIdentifier(draggedPackageId)?.Name;
            if (string.IsNullOrEmpty(label)) return;

            const float previewWidth = 280f;
            bool previewingGroup = draggingGroup;
            float previewHeight = previewingGroup ? 48f : 28f;
            Vector2 mouse = Event.current.mousePosition;
            float x = Math.Max(listRect.xMin, Math.Min(mouse.x + 12f, listRect.xMax - previewWidth));
            float y = Math.Max(listRect.yMin, Math.Min(mouse.y + 12f, listRect.yMax - previewHeight));
            Rect previewRect = new Rect(x, y, previewWidth, previewHeight);
            Widgets.DrawBoxSolid(previewRect, new Color(0.12f, 0.19f, 0.28f, 0.96f));
            Widgets.DrawBox(previewRect);
            Widgets.Label(new Rect(previewRect.x + 8f, previewRect.y, previewRect.width - 16f, 24f), label);
            if (previewingGroup)
            {
                string placement = headerDragTarget == null ? "MG_MoveToGroupEdge" : (dropAfterHeaderTarget ? "MG_MoveBelow" : "MG_MoveAbove");
                Widgets.Label(new Rect(previewRect.x + 8f, previewRect.y + 22f, previewRect.width - 16f, 24f), placement.Translate());
            }
        }

        private static void ClearActiveDrag()
        {
            draggedPackageId = null;
            dragTargetPackageId = null;
            activeDragGroup = null;
            if (GUIUtility.hotControl == dragControlId)
                GUIUtility.hotControl = 0;
        }
    }

    /// <summary>Lets the selected mod be assigned directly from its native info panel.</summary>
    [HarmonyPatch(typeof(Page_ModsConfig), "DoModInfo")]
    public static class Patch_PageModsConfig_DoModInfo
    {
        public static void Postfix(Rect __0, ModMetaData __1)
        {
            if (__1 == null) return;
            float y = __0.yMax - 31f;
            Rect groupButton = new Rect(__0.xMin, y, Math.Min(165f, __0.width), 30f);
            var currentGroup = Patch_PageModsConfig_DoWindowContents.FindGroup(__1.PackageId);
            string label = currentGroup == null ? "MG_AddToGroup".Translate() : "MG_GroupLabel".Translate(currentGroup.name);
            if (Widgets.ButtonText(groupButton, label))
            {
                var settings = ModGroupsMod.Settings;
                var options = new List<FloatMenuOption>();
                options.Add(new FloatMenuOption("MG_NoGroup".Translate(), () =>
                {
                    foreach (var group in settings.groups) group.packageIds.Remove(__1.PackageId);
                    settings.Save();
                }));
                foreach (var group in settings.groups)
                {
                    var selectedGroup = group;
                    options.Add(new FloatMenuOption(group.name, () =>
                    {
                        foreach (var other in settings.groups) other.packageIds.Remove(__1.PackageId);
                        if (!selectedGroup.packageIds.Contains(__1.PackageId)) selectedGroup.packageIds.Add(__1.PackageId);
                        if (!settings.knownPackageIds.Contains(__1.PackageId)) settings.knownPackageIds.Add(__1.PackageId);
                        settings.Save();
                    }));
                }
                if (settings.groups.Count == 0) options.Add(new FloatMenuOption("MG_CreateGroupManage".Translate(), null));
                Find.WindowStack.Add(new FloatMenu(options));
            }
        }
    }
}
