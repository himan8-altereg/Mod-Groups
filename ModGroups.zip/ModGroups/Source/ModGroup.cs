using System.Collections.Generic;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// A single user-created group: a name, the set of mod packageIds it contains,
    /// and whether it's currently collapsed in the UI.
    /// </summary>
    public class ModGroup : IExposable
    {
        public string name;
        public List<string> packageIds = new List<string>();
        public bool collapsed = false;
        public bool collapsedActive = false;
        public bool collapsedInactive = false;
        public bool collapsedShared = false;
        public bool collapsedSharedActive = false;
        public bool collapsedSharedInactive = false;
        public bool pinned = false; // exception: "Hide grouped mods" skips pinned groups
        public string colorHex = "#383838";

        // Parameterless constructor required by Scribe for deserialization.
        public ModGroup()
        {
        }

        public ModGroup(string name)
        {
            this.name = name;
        }

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name");
            Scribe_Collections.Look(ref packageIds, "packageIds", LookMode.Value);
            Scribe_Values.Look(ref collapsed, "collapsed", false);
            Scribe_Values.Look(ref collapsedActive, "collapsedActive", collapsed);
            Scribe_Values.Look(ref collapsedInactive, "collapsedInactive", collapsed);
            Scribe_Values.Look(ref collapsedShared, "collapsedShared", false);
            Scribe_Values.Look(ref collapsedSharedActive, "collapsedSharedActive", collapsedShared);
            Scribe_Values.Look(ref collapsedSharedInactive, "collapsedSharedInactive", collapsedShared);
            Scribe_Values.Look(ref pinned, "pinned", false);
            Scribe_Values.Look(ref colorHex, "colorHex", "#383838");

            if (packageIds == null)
            {
                packageIds = new List<string>();
            }
        }
    }
}
