using System;
using HarmonyLib;
using UnityEngine;
using Verse;

namespace ModGroups
{
    public class ModGroupsMod : Mod
    {
        public static ModGroupsSettings Settings;
        public static ModGroupsMod Instance;

        public ModGroupsMod(ModContentPack content) : base(content)
        {
            Instance = this;
            Settings = GetSettings<ModGroupsSettings>();

            try
            {
                var harmony = new Harmony("dmitri.modgroups");
                harmony.PatchAll();
            }
            catch (Exception ex)
            {
                // Don't let a patching failure take down the whole mod's
                // instantiation - log it clearly instead so the rest of the
                // mod list still loads and we get a readable error.
                Log.Error($"[Mod Groups] Failed to apply Harmony patches: {ex}");
            }
        }

        public override string SettingsCategory()
        {
            return "MG_SettingsCategory".Translate();
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            var listing = new Listing_Standard();
            listing.Begin(inRect);
            listing.Label("MG_CommunityDescription".Translate());
            if (Widgets.ButtonText(listing.GetRect(30f), "MG_OpenGitHub".Translate()))
            {
                Application.OpenURL("https://github.com/himan8-altereg/Mod-Groups");
            }
            if (Widgets.ButtonText(listing.GetRect(30f), "MG_OpenAuthorTelegram".Translate()))
            {
                Application.OpenURL("https://t.me/dnevnichek_Zinoflakcin");
            }
            listing.Gap();
            listing.Label("MG_ManageDescription".Translate());
            listing.Label("MG_SavedCount".Translate(Settings.groups.Count));
            listing.GapLine();
            listing.Label("MG_GroupDragMode".Translate());
            string holdLabel = (Settings.clickToDragGroups ? "○ " : "● ") + "MG_DragHold".Translate();
            if (Widgets.ButtonText(listing.GetRect(30f), holdLabel) && Settings.clickToDragGroups)
            {
                Settings.clickToDragGroups = false;
                Settings.Save();
            }
            listing.Label("MG_DragHoldHelp".Translate());
            string clickLabel = (Settings.clickToDragGroups ? "● " : "○ ") + "MG_DragClick".Translate();
            if (Widgets.ButtonText(listing.GetRect(30f), clickLabel) && !Settings.clickToDragGroups)
            {
                Settings.clickToDragGroups = true;
                Settings.Save();
            }
            listing.Label("MG_DragClickHelp".Translate());
            listing.End();
            base.DoSettingsWindowContents(inRect);
        }

        public override void WriteSettings()
        {
            base.WriteSettings();
        }
    }
}
