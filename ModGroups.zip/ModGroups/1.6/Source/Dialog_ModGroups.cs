using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

// FILE GUIDE: The standalone and embedded Mod Groups window.
// Layout, search, selection, group creation, colors, and list drawing live here.
// GroupColorHexes and GroupColorNames are the palette; MG_* labels are in language XML.
// integratedMode changes which controls appear. Size and color values can be customized.
// Drag-state fields and their event handlers work together to move mods and groups.
namespace ModGroups
{
    /// <summary>
    /// Custom window listing every installed mod, organized into user-defined,
    /// collapsible groups. Opened via the "Mod Groups" button injected into the
    /// vanilla mod list page (see Patch_PageModsConfig).
    ///
    /// NOTE on ModMetaData.Active: this build assumes it has a public setter
    /// (true in most recent RimWorld versions). If your compiler complains,
    /// replace "mod.Active = x;" with "ModsConfig.SetActive(mod.PackageId, x);"
    /// which is the underlying API this normally calls into.
    /// </summary>
    public class Dialog_ModGroups : Window
    {
        private Vector2 scrollPosition = Vector2.zero;
        private float viewHeight = 1000f;
        private string newGroupName = "";
        private string renamingGroupName = null;
        private string renameBuffer = "";
        private bool ungroupedCollapsed = false;
        private bool newModsCollapsed = false;
        private readonly HashSet<string> selected = new HashSet<string>();
        private string draggingPackageId;
        private string dragTargetPackageId;
        private ModGroup draggingGroup;
        private int dragControlId;
        private bool dropAfterTarget;
        private ModGroup draggingHeaderGroup;
        private ModGroup groupDropTarget;
        private int groupDragControlId;
        private bool dropAfterGroupTarget;
        private readonly bool integratedMode;
        private string searchText = "";

        private static readonly string[] GroupColorHexes =
        {
            "#383838", "#8F3434", "#A45E22", "#8A7820", "#397344",
            "#28777A", "#315F9A", "#67458C", "#984D79", "#777777"
        };

        private static readonly string[] GroupColorNames =
        {
            "MG_ColorGray", "MG_ColorRed", "MG_ColorOrange", "MG_ColorYellow", "MG_ColorGreen",
            "MG_ColorTeal", "MG_ColorBlue", "MG_ColorPurple", "MG_ColorPink", "MG_ColorLightGray"
        };

        public override Vector2 InitialSize => new Vector2(960f, 700f);

        public Dialog_ModGroups() : this(false)
        {
        }

        public Dialog_ModGroups(bool integratedMode)
        {
            this.integratedMode = integratedMode;
            doCloseButton = true;
            doCloseX = true;
            forcePause = true;
            absorbInputAroundWindow = true;

            // First time this window is ever opened, baseline "known" mods to
            // everything currently installed, so nothing shows up as "new"
            // retroactively - only mods that appear from now on will.
            var settings = ModGroupsMod.Settings;
            if (settings.knownPackageIds.Count == 0)
            {
                settings.knownPackageIds.AddRange(ModLister.AllInstalledMods.Where(m => !IsCoreMod(m)).Select(m => m.PackageId));
                settings.Save();
            }
        }

        public override void DoWindowContents(Rect inRect)
        {
            var settings = ModGroupsMod.Settings;

            // --- row 1: create a new group ---
            Rect nameFieldRect = new Rect(0f, 0f, inRect.width - (integratedMode ? 140f : 356f), 30f);
            Rect addButtonRect = new Rect(inRect.width - (integratedMode ? 130f : 350f), 0f, integratedMode ? 130f : 112f, 30f);

            newGroupName = Widgets.TextField(nameFieldRect, newGroupName);
            if (Widgets.ButtonText(addButtonRect, "MG_NewGroup".Translate()) && !string.IsNullOrWhiteSpace(newGroupName))
            {
                if (!settings.groups.Any(g => g.name == newGroupName))
                {
                    settings.groups.Add(new ModGroup(newGroupName));
                    settings.Save();
                }
                newGroupName = "";
            }

            if (!integratedMode && Widgets.ButtonText(new Rect(inRect.width - 232f, 0f, 112f, 30f), "MG_Apply".Translate()))
            {
                settings.Save();
                Close();
            }
            if (!integratedMode && Widgets.ButtonText(new Rect(inRect.width - 114f, 0f, 114f, 30f), "MG_Cancel".Translate()))
            {
                settings.Save();
                ModsConfig.Save();
                Close();
            }

            if (integratedMode)
            {
                Rect searchLabelRect = new Rect(0f, 36f, 64f, 30f);
                Widgets.Label(searchLabelRect, "MG_Search".Translate());
                searchText = Widgets.TextField(new Rect(68f, 36f, Math.Min(280f, inRect.width - 80f), 30f), searchText);
            }

            // --- row 2: bulk actions for whatever's currently ticked ---
            float actionY = integratedMode ? 72f : 36f;
            Rect selectedLabelRect = new Rect(0f, actionY, inRect.width - 340f, 30f);
            Widgets.Label(selectedLabelRect, selected.Count > 0 ? "MG_SelectedCount".Translate(selected.Count) : "MG_TickMods".Translate());

            Rect bulkMoveRect = new Rect(inRect.width - 330f, actionY, 175f, 30f);
            Rect clearRect = new Rect(inRect.width - 150f, actionY, 150f, 30f);

            GUI.enabled = selected.Count > 0;
            if (Widgets.ButtonText(bulkMoveRect, "MG_AddSelected".Translate()))
            {
                var options = new List<FloatMenuOption>();
                foreach (var g in settings.groups)
                {
                    options.Add(new FloatMenuOption(g.name, () =>
                    {
                        foreach (var pkgId in selected)
                        {
                            if (!g.packageIds.Contains(pkgId))
                            {
                                g.packageIds.Add(pkgId);
                            }
                            if (!settings.knownPackageIds.Contains(pkgId))
                            {
                                settings.knownPackageIds.Add(pkgId);
                            }
                        }
                        settings.Save();
                        selected.Clear();
                    }));
                }
                options.Add(new FloatMenuOption("MG_RemoveAllGroups".Translate(), () =>
                {
                    foreach (var g in settings.groups)
                    {
                        foreach (var pkgId in selected)
                        {
                            g.packageIds.Remove(pkgId);
                        }
                    }
                    settings.Save();
                    selected.Clear();
                }));
                if (settings.groups.Count == 0)
                {
                    options.Insert(0, new FloatMenuOption("MG_CreateGroupFirst".Translate(), null));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }
            if (Widgets.ButtonText(clearRect, "MG_ClearSelection".Translate()))
            {
                selected.Clear();
            }
            GUI.enabled = true;

            // --- row 3: collapse/expand every group at once ---
            float groupActionY = actionY + 36f;
            Rect hideGroupedRect = new Rect(0f, groupActionY, 220f, 30f);
            Rect expandAllRect = new Rect(230f, groupActionY, 140f, 30f);

            if (Widgets.ButtonText(hideGroupedRect, "MG_HideGrouped".Translate()))
            {
                foreach (var g in settings.groups)
                {
                    if (!g.pinned)
                    {
                        g.collapsed = true;
                        g.collapsedActive = true;
                        g.collapsedInactive = true;
                        g.collapsedShared = true;
                        g.collapsedSharedActive = true;
                        g.collapsedSharedInactive = true;
                    }
                }
                settings.Save();
            }
            if (Widgets.ButtonText(expandAllRect, "MG_ExpandAll".Translate()))
            {
                foreach (var g in settings.groups)
                {
                    g.collapsed = false;
                    g.collapsedActive = false;
                    g.collapsedInactive = false;
                    g.collapsedShared = false;
                    g.collapsedSharedActive = false;
                    g.collapsedSharedInactive = false;
                }
                settings.Save();
            }

            // --- scrollable list: new mods (if any) + groups + ungrouped ---
            float listStartY = groupActionY + 38f;
            Rect listOuter = new Rect(0f, listStartY, inRect.width, inRect.height - listStartY);
            Rect listInner = new Rect(0f, 0f, listOuter.width - 16f, viewHeight);

            Widgets.BeginScrollView(listOuter, ref scrollPosition, listInner);

            float curY = 0f;
            var allMods = ModLister.AllInstalledMods
                .Where(m => !IsCoreMod(m))
                .Where(m => string.IsNullOrWhiteSpace(searchText) || m.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0 || m.PackageId.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                .OrderBy(m => m.Name).ToList();
            var groupedIds = new HashSet<string>(settings.groups.SelectMany(g => g.packageIds));

            if (draggingHeaderGroup != null && (Event.current.type == EventType.MouseMove
                || Event.current.type == EventType.MouseDrag || Event.current.type == EventType.MouseUp))
                groupDropTarget = null;

            var newMods = allMods.Where(m => !settings.knownPackageIds.Contains(m.PackageId)).ToList();
            if (newMods.Count > 0)
            {
                curY = DrawNewMods(listInner.width, curY, newMods, settings);
            }

            foreach (var group in settings.groups.ToList())
            {
                curY = DrawGroup(listInner.width, curY, group, allMods, settings);
            }

            var ungrouped = allMods.Where(m => !groupedIds.Contains(m.PackageId)).ToList();
            curY = DrawUngrouped(listInner.width, curY, ungrouped, settings);

            viewHeight = curY + 20f;
            Widgets.EndScrollView();

            if (settings.clickToDragGroups && draggingHeaderGroup != null
                && Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                draggingHeaderGroup = null;
                groupDropTarget = null;
                Event.current.Use();
            }

            if (Event.current.type == EventType.MouseUp && draggingPackageId != null)
            {
                draggingPackageId = null;
                dragTargetPackageId = null;
                draggingGroup = null;
                GUIUtility.hotControl = 0;
            }
            if (!settings.clickToDragGroups && Event.current.type == EventType.MouseUp && draggingHeaderGroup != null)
            {
                draggingHeaderGroup = null;
                groupDropTarget = null;
                GUIUtility.hotControl = 0;
            }
            DrawDragPreview(inRect);
        }

        public override void PostClose()
        {
            // Every action is persisted immediately; closing with Esc must not
            // roll back edits just because Apply was not clicked.
            ModsConfig.Save();
            ModGroupsMod.Settings.Save();
            base.PostClose();
        }

        private static bool IsCoreMod(ModMetaData mod)
        {
            return mod != null && string.Equals(mod.PackageId, "ludeon.rimworld", StringComparison.OrdinalIgnoreCase);
        }

        private float DrawNewMods(float width, float y, List<ModMetaData> mods, ModGroupsSettings settings)
        {
            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, new Color(0.45f, 0.32f, 0.05f, 0.6f)); // amber - stands out

            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, newModsCollapsed ? "+" : "-"))
            {
                newModsCollapsed = !newModsCollapsed;
            }

            Rect nameRect = new Rect(32f, y, width - 32f - 150f, 30f);
            Widgets.Label(nameRect, "MG_NewModsCount".Translate(mods.Count));

            Rect markSeenRect = new Rect(width - 145f, y + 1f, 145f, 28f);
            if (Widgets.ButtonText(markSeenRect, "MG_MarkAllSeen".Translate()))
            {
                foreach (var mod in mods)
                {
                    if (!settings.knownPackageIds.Contains(mod.PackageId))
                    {
                        settings.knownPackageIds.Add(mod.PackageId);
                    }
                }
                settings.Save();
            }

            y += 32f;

            if (!newModsCollapsed)
            {
                foreach (var mod in mods)
                {
                    y = DrawModRow(width, y, mod, null, settings);
                }
            }

            return y + 8f;
        }

        private float DrawGroup(float width, float y, ModGroup group, List<ModMetaData> allMods, ModGroupsSettings settings)
        {
            var groupMods = allMods.Where(m => group.packageIds.Contains(m.PackageId))
                .OrderBy(m => group.packageIds.IndexOf(m.PackageId)).ToList();

            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, GroupColor(group));
            Rect groupDragRect = new Rect(52f, y, width - 52f - 472f, 30f);
            Rect nameRect = new Rect(54f, y, width - 54f - 472f, 30f);
            HandleGroupHeaderDrag(headerRect, groupDragRect, group, settings);
            if (draggingHeaderGroup == group)
                Widgets.DrawBoxSolid(headerRect, new Color(0.28f, 0.62f, 0.92f, 0.25f));

            // Collapse / expand toggle
            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, group.collapsed ? "+" : "-"))
            {
                group.collapsed = !group.collapsed;
                group.collapsedActive = group.collapsed;
                group.collapsedInactive = group.collapsed;
                group.collapsedShared = group.collapsed;
                group.collapsedSharedActive = group.collapsed;
                group.collapsedSharedInactive = group.collapsed;
                settings.Save();
            }

            // Enable/disable every mod in this group at once
            Rect checkRect = new Rect(32f, y + 6f, 18f, 18f);
            bool allActive = groupMods.Count > 0 && groupMods.All(m => m.Active);
            bool newState = allActive;
            Widgets.Checkbox(new Vector2(checkRect.x, checkRect.y), ref newState);
            if (newState != allActive)
            {
                foreach (var m in groupMods)
                {
                    m.Active = newState;
                }
                ModsConfig.Save();
            }

            Rect colorRect = new Rect(width - 398f, y + 1f, 66f, 28f);
            Rect sortRect = new Rect(width - 468f, y + 1f, 66f, 28f);
            Rect pinRect = new Rect(width - 328f, y + 1f, 80f, 28f);
            Rect renameRect = new Rect(width - 244f, y + 1f, 108f, 28f);
            Rect deleteRect = new Rect(width - 132f, y + 1f, 76f, 28f);
            Rect confirmRect = new Rect(width - 52f, y + 1f, 52f, 28f);

            if (Widgets.ButtonText(sortRect, "MG_SortGroup".Translate()))
            {
                SortGroupByGameOrder(group);
                settings.Save();
            }
            TooltipHandler.TipRegion(sortRect, "MG_SortGroupTooltip".Translate());

            if (Widgets.ButtonText(colorRect, "MG_Color".Translate()))
            {
                var colorOptions = new List<FloatMenuOption>();
                for (int i = 0; i < GroupColorHexes.Length; i++)
                {
                    string colorHex = GroupColorHexes[i];
                    string colorName = GroupColorNames[i].Translate();
                    colorOptions.Add(new FloatMenuOption(colorName, () =>
                    {
                        group.colorHex = colorHex;
                        settings.Save();
                    }));
                }
                Find.WindowStack.Add(new FloatMenu(colorOptions));
            }

            if (Widgets.ButtonText(pinRect, group.pinned ? "MG_Unpin".Translate() : "MG_Pin".Translate()))
            {
                group.pinned = !group.pinned;
                settings.Save();
            }

            if (renamingGroupName == group.name)
            {
                renameBuffer = Widgets.TextField(nameRect, renameBuffer);
                if (Widgets.ButtonText(confirmRect, "MG_OK".Translate()))
                {
                    if (!string.IsNullOrWhiteSpace(renameBuffer))
                    {
                        group.name = renameBuffer;
                        settings.Save();
                    }
                    renamingGroupName = null;
                }
            }
            else
            {
                Widgets.Label(nameRect, "MG_GroupNameCount".Translate((group.pinned ? "* " : "") + group.name, groupMods.Count));
                if (Widgets.ButtonText(renameRect, "MG_Rename".Translate()))
                {
                    renamingGroupName = group.name;
                    renameBuffer = group.name;
                }
                if (Widgets.ButtonText(deleteRect, "MG_Delete".Translate()))
                {
                    settings.groups.Remove(group);
                    settings.Save();
                }
            }

            if (draggingHeaderGroup != null && groupDropTarget == group)
            {
                float markerY = dropAfterGroupTarget ? headerRect.yMax - 3f : headerRect.y;
                Widgets.DrawBoxSolid(new Rect(headerRect.x, markerY, headerRect.width, 3f), new Color(0.28f, 0.76f, 1f, 1f));
            }

            y += 32f;

            if (!group.collapsed)
            {
                foreach (var mod in groupMods)
                {
                    y = DrawModRow(width, y, mod, group, settings);
                }
            }

            return y + 8f;
        }

        public static Color GroupColor(ModGroup group)
        {
            Color color;
            if (group != null && !string.IsNullOrEmpty(group.colorHex) && ColorUtility.TryParseHtmlString(group.colorHex, out color))
            {
                color.a = 0.72f;
                return color;
            }
            return new Color(0.22f, 0.22f, 0.22f, 0.6f);
        }

        private float DrawUngrouped(float width, float y, List<ModMetaData> mods, ModGroupsSettings settings)
        {
            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, new Color(0.15f, 0.15f, 0.15f, 0.5f));

            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, ungroupedCollapsed ? "+" : "-"))
            {
                ungroupedCollapsed = !ungroupedCollapsed;
            }

            Rect nameRect = new Rect(32f, y, width - 32f, 30f);
            Widgets.Label(nameRect, "MG_UngroupedCount".Translate(mods.Count));

            y += 32f;

            if (!ungroupedCollapsed)
            {
                foreach (var mod in mods)
                {
                    y = DrawModRow(width, y, mod, null, settings);
                }
            }

            return y + 8f;
        }

        private float DrawModRow(float width, float y, ModMetaData mod, ModGroup currentGroup, ModGroupsSettings settings)
        {
            Rect rowRect = new Rect(24f, y, width - 24f, 28f);
            bool isDraggedRow = draggingHeaderGroup == null && currentGroup != null
                && currentGroup == draggingGroup && mod.PackageId == draggingPackageId;
            if (isDraggedRow)
                Widgets.DrawBoxSolid(rowRect, new Color(0.30f, 0.62f, 0.92f, 0.28f));

            // Selection checkbox (for bulk "Add selected to..")
            Rect selectRect = new Rect(rowRect.x, rowRect.y + 5f, 18f, 18f);
            bool isSelected = selected.Contains(mod.PackageId);
            bool newSelected = isSelected;
            Widgets.Checkbox(new Vector2(selectRect.x, selectRect.y), ref newSelected);
            if (newSelected != isSelected)
            {
                if (newSelected) selected.Add(mod.PackageId);
                else selected.Remove(mod.PackageId);
            }

            // Active/enabled checkbox
            Rect checkRect = new Rect(rowRect.x + 24f, rowRect.y + 5f, 18f, 18f);
            bool active = mod.Active;
            bool newActive = active;
            Widgets.Checkbox(new Vector2(checkRect.x, checkRect.y), ref newActive);
            if (newActive != active)
            {
                mod.Active = newActive;
                ModsConfig.Save();
            }

            const float moveButtonWidth = 150f;
            float labelStart = 48f;
            Rect labelRect = new Rect(rowRect.x + labelStart, rowRect.y, rowRect.width - labelStart - moveButtonWidth - 8f, 28f);
            Rect moveRect = new Rect(rowRect.xMax - moveButtonWidth, rowRect.y + 1f, moveButtonWidth, 26f);
            Widgets.Label(labelRect, mod.Name);
            if (currentGroup != null)
            {
                HandleModDrag(rowRect, selectRect, checkRect, moveRect, mod, currentGroup, settings);
            }

            if (Widgets.ButtonText(moveRect, "MG_AddToGroup".Translate()))
            {
                var options = new List<FloatMenuOption>();
                foreach (var g in settings.groups)
                {
                    if (g.packageIds.Contains(mod.PackageId)) continue; // already in this group
                    options.Add(new FloatMenuOption(g.name, () =>
                    {
                        g.packageIds.Add(mod.PackageId);
                        if (!settings.knownPackageIds.Contains(mod.PackageId))
                        {
                            settings.knownPackageIds.Add(mod.PackageId);
                        }
                        settings.Save();
                    }));
                }
                if (currentGroup != null)
                {
                    options.Add(new FloatMenuOption("MG_RemoveFromThisGroup".Translate(), () =>
                    {
                        currentGroup.packageIds.Remove(mod.PackageId);
                        settings.Save();
                    }));
                }
                if (options.Count == 0)
                {
                    options.Add(new FloatMenuOption("MG_CreateGroupFirst".Translate(), null));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }

            if (draggingHeaderGroup == null && currentGroup != null && currentGroup == draggingGroup && mod.PackageId == dragTargetPackageId)
            {
                float markerY = dropAfterTarget ? rowRect.yMax - 2f : rowRect.y;
                Widgets.DrawBoxSolid(new Rect(rowRect.x, markerY, rowRect.width, 3f), new Color(0.28f, 0.76f, 1f, 1f));
            }
            return y + 28f;
        }

        private void HandleModDrag(Rect rowRect, Rect selectionRect, Rect activeRect, Rect actionRect, ModMetaData mod, ModGroup currentGroup, ModGroupsSettings settings)
        {
            if (currentGroup == null || draggingHeaderGroup != null)
                return;

            int controlId = GUIUtility.GetControlID(FocusType.Passive);
            Event current = Event.current;

            bool overInteractiveControl = selectionRect.Contains(current.mousePosition)
                || activeRect.Contains(current.mousePosition)
                || actionRect.Contains(current.mousePosition);
            if (current.type == EventType.MouseDown && current.button == 0
                && rowRect.Contains(current.mousePosition) && !overInteractiveControl)
            {
                draggingPackageId = mod.PackageId;
                dragTargetPackageId = mod.PackageId;
                draggingGroup = currentGroup;
                dragControlId = controlId;
                dropAfterTarget = false;
                GUIUtility.hotControl = controlId;
                current.Use();
                return;
            }

            if (draggingPackageId == null || draggingGroup != currentGroup)
                return;

            if (current.type == EventType.MouseDrag && rowRect.Contains(current.mousePosition))
            {
                dragTargetPackageId = mod.PackageId;
                dropAfterTarget = current.mousePosition.y >= rowRect.center.y;
                GUI.changed = true;
            }

            if (current.type == EventType.MouseUp && GUIUtility.hotControl == dragControlId && controlId == dragControlId)
            {
                int sourceIndex = draggingGroup.packageIds.IndexOf(draggingPackageId);
                int targetIndex = draggingGroup.packageIds.IndexOf(dragTargetPackageId);
                if (sourceIndex >= 0 && targetIndex >= 0 && sourceIndex != targetIndex)
                {
                    string packageId = draggingGroup.packageIds[sourceIndex];
                    draggingGroup.packageIds.RemoveAt(sourceIndex);
                    if (sourceIndex < targetIndex)
                        targetIndex--;
                    int insertIndex = targetIndex + (dropAfterTarget ? 1 : 0);
                    draggingGroup.packageIds.Insert(Math.Max(0, Math.Min(insertIndex, draggingGroup.packageIds.Count)), packageId);
                    settings.Save();
                }

                draggingPackageId = null;
                dragTargetPackageId = null;
                draggingGroup = null;
                GUIUtility.hotControl = 0;
                current.Use();
            }
        }

        private static void SortGroupByGameOrder(ModGroup group)
        {
            var gameOrder = ModsConfig.ActiveModsInLoadOrder
                .Select(mod => mod.PackageId)
                .Concat(ModLister.AllInstalledMods.Select(mod => mod.PackageId))
                .Distinct()
                .Select((packageId, index) => new { packageId, index })
                .ToDictionary(item => item.packageId, item => item.index);

            group.packageIds = group.packageIds
                .Select((packageId, currentIndex) => new { packageId, currentIndex })
                .OrderBy(item => gameOrder.TryGetValue(item.packageId, out int gameIndex) ? gameIndex : int.MaxValue)
                .ThenBy(item => item.currentIndex)
                .Select(item => item.packageId)
                .ToList();
        }

        private void HandleGroupHeaderDrag(Rect headerRect, Rect dragRect, ModGroup group, ModGroupsSettings settings)
        {
            int controlId = GUIUtility.GetControlID(FocusType.Passive);
            Event current = Event.current;

            if (settings.clickToDragGroups && current.type == EventType.MouseDown && current.button == 0
                && dragRect.Contains(current.mousePosition) && renamingGroupName != group.name)
            {
                if (draggingHeaderGroup == null)
                {
                    draggingHeaderGroup = group;
                    groupDropTarget = null;
                    groupDragControlId = controlId;
                }
                else if (TryGetGroupDropSide(headerRect, current.mousePosition, out bool after))
                {
                    groupDropTarget = group;
                    dropAfterGroupTarget = after;
                    MoveGroup(settings, draggingHeaderGroup, groupDropTarget, dropAfterGroupTarget);
                    draggingHeaderGroup = null;
                    groupDropTarget = null;
                }
                current.Use();
                return;
            }

            if (!settings.clickToDragGroups && current.type == EventType.MouseDown && current.button == 0 && dragRect.Contains(current.mousePosition)
                && renamingGroupName != group.name && draggingHeaderGroup == null)
            {
                draggingHeaderGroup = group;
                groupDropTarget = group;
                groupDragControlId = controlId;
                dropAfterGroupTarget = false;
                GUIUtility.hotControl = controlId;
                current.Use();
                return;
            }

            if (draggingHeaderGroup == null)
                return;

            if ((current.type == EventType.MouseMove || current.type == EventType.MouseDrag || current.type == EventType.Repaint || current.type == EventType.MouseUp)
                && TryGetGroupDropSide(headerRect, current.mousePosition, out bool dropAfter))
            {
                groupDropTarget = group;
                dropAfterGroupTarget = dropAfter;
            }

            if (current.type == EventType.MouseUp && GUIUtility.hotControl == groupDragControlId && groupDropTarget == group)
            {
                MoveGroup(settings, draggingHeaderGroup, groupDropTarget, dropAfterGroupTarget);
                draggingHeaderGroup = null;
                groupDropTarget = null;
                GUIUtility.hotControl = 0;
                current.Use();
            }
        }

        private static bool TryGetGroupDropSide(Rect headerRect, Vector2 mousePosition, out bool after)
        {
            const float edgeHeight = 5f;
            after = false;
            if (!headerRect.Contains(mousePosition)) return false;
            if (mousePosition.y <= headerRect.yMin + edgeHeight) return true;
            if (mousePosition.y >= headerRect.yMax - edgeHeight)
            {
                after = true;
                return true;
            }
            return false;
        }

        private static void MoveGroup(ModGroupsSettings settings, ModGroup moving, ModGroup target, bool after)
        {
            int sourceIndex = settings.groups.IndexOf(moving);
            int targetIndex = settings.groups.IndexOf(target);
            if (sourceIndex < 0 || targetIndex < 0) return;
            settings.groups.RemoveAt(sourceIndex);
            if (sourceIndex < targetIndex) targetIndex--;
            int insertIndex = targetIndex + (after ? 1 : 0);
            settings.groups.Insert(Math.Max(0, Math.Min(insertIndex, settings.groups.Count)), moving);
            settings.Save();
        }

        private void DrawDragPreview(Rect inRect)
        {
            if ((draggingPackageId == null && draggingHeaderGroup == null) || Event.current.type != EventType.Repaint)
                return;

            string label = draggingHeaderGroup != null
                ? draggingHeaderGroup.name
                : ModLister.GetModWithIdentifier(draggingPackageId)?.Name;
            if (string.IsNullOrEmpty(label)) return;

            const float previewWidth = 300f;
            bool previewingGroup = draggingHeaderGroup != null;
            float previewHeight = previewingGroup ? 50f : 30f;
            Vector2 mouse = Event.current.mousePosition;
            float x = Math.Max(inRect.xMin, Math.Min(mouse.x + 14f, inRect.xMax - previewWidth));
            float y = Math.Max(inRect.yMin, Math.Min(mouse.y + 14f, inRect.yMax - previewHeight));
            Rect previewRect = new Rect(x, y, previewWidth, previewHeight);
            Widgets.DrawBoxSolid(previewRect, new Color(0.12f, 0.19f, 0.28f, 0.96f));
            Widgets.DrawBox(previewRect);
            Widgets.Label(new Rect(previewRect.x + 8f, previewRect.y, previewRect.width - 16f, 26f), label);
            if (previewingGroup)
            {
                string placement = groupDropTarget == null ? "MG_MoveToGroupEdge" : (dropAfterGroupTarget ? "MG_MoveBelow" : "MG_MoveAbove");
                Widgets.Label(new Rect(previewRect.x + 8f, previewRect.y + 24f, previewRect.width - 16f, 24f), placement.Translate());
            }
        }
    }
}
